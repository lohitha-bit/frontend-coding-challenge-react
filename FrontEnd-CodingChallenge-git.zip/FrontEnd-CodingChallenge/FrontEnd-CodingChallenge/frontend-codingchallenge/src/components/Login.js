import React, { useState } from 'react';
import { Button, Form, Grid, Header, Message, Segment } from 'semantic-ui-react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  
  const handleChange = (e, { name, value }) => {
    setFormData({ ...formData, [name]: value });
  };
  
  const handleSubmit = async () => {
    try {
      const response = await axios.post('http://localhost:9000/user/login', formData);
      localStorage.setItem('token', response.data.jwt);
      setError('');
      navigate('/');
    } catch (err) {
      setError('Invalid username or password');
    }
  };
  
  return (
    <Grid 
      textAlign='center' 
      verticalAlign='middle' 
      style={{ 
        height: '100vh', 
        backgroundImage: 'url(https://source.unsplash.com/random/1600x900/?nature,water)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <Grid.Column style={{ 
        maxWidth: 400,
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        padding: '2em',
        borderRadius: '10px',
        boxShadow: '0 4px 8px rgba(0,0,0,0.2)'
      }}>
        <Header 
          as='h2' 
          color='teal' 
          textAlign='center'
          style={{ 
            fontSize: '2.5em',
            fontWeight: 'bold',
            marginBottom: '1.5em',
            color: '#1a8754'
          }}
        >
          Login to your account
        </Header>
        <Form size='large' onSubmit={handleSubmit} style={{ fontSize: '1.1em' }}>
          <Segment stacked style={{ 
            padding: '2em',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px'
          }}>
            <Form.Input
              fluid
              icon='user'
              iconPosition='left'
              placeholder='Username'
              name='username'
              value={formData.username}
              onChange={handleChange}
              required
              style={{ 
                fontSize: '1.2em',
                padding: '1em',
                marginBottom: '1.5em'
              }}
            />
            <Form.Input
              fluid
              icon='lock'
              iconPosition='left'
              placeholder='Password'
              type='password'
              name='password'
              value={formData.password}
              onChange={handleChange}
              required
              style={{ 
                fontSize: '1.2em',
                padding: '1em',
                marginBottom: '1.5em'
              }}
            />
            <Button 
              color='teal' 
              fluid 
              size='large'
              style={{ 
                fontSize: '1.3em',
                fontWeight: 'bold',
                padding: '1em',
                backgroundColor: '#1a8754',
                borderColor: '#1a8754'
              }}
            >
              Login
            </Button>
          </Segment>
        </Form>
        {error && (
          <Message 
            negative 
            style={{ 
              fontSize: '1.1em',
              marginTop: '1.5em',
              backgroundColor: '#f8d7da',
              borderColor: '#f5c6cb',
              color: '#721c24'
            }}
          >
            {error}
          </Message>
        )}
        <Message 
          style={{ 
            fontSize: '1.1em',
            marginTop: '1.5em',
            color: '#6c757d'
          }}
        >
          New user? <a href='/register' style={{ color: '#1a8754', fontWeight: 'bold' }}>Register</a>
        </Message>
      </Grid.Column>
    </Grid>
  );
};

export default Login;