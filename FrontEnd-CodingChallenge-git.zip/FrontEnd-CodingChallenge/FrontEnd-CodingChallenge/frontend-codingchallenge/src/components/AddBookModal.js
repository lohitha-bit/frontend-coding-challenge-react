import React, { useState } from 'react';
import { Modal, Button, Form } from 'semantic-ui-react';

const AddBookModal = ({ open, onClose, onAdd }) => {
  const [book, setBook] = useState({ isbn: '', title: '', author: '', publicationYear: '' });

  const handleChange = (e, { name, value }) => {
    setBook({ ...book, [name]: value });
  };

  const handleSubmit = () => {
    onAdd(book);
    setBook({ isbn: '', title: '', author: '', publicationYear: '' });
  };

  return (
    <Modal open={open} onClose={onClose} size="tiny">
      <Modal.Header>Add New Book</Modal.Header>
      <Modal.Content>
        <Form onSubmit={handleSubmit}>
          <Form.Input label="ISBN" name="isbn" value={book.isbn} onChange={handleChange} required />
          <Form.Input label="Title" name="title" value={book.title} onChange={handleChange} required />
          <Form.Input label="Author" name="author" value={book.author} onChange={handleChange} required />
          <Form.Input
            label="Publication Year"
            name="publicationYear"
            type="number"
            value={book.publicationYear}
            onChange={handleChange}
            required
          />
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button onClick={onClose}>Cancel</Button>
        <Button positive onClick={handleSubmit}>
          Add
        </Button>
      </Modal.Actions>
    </Modal>
  );
};

export default AddBookModal;
