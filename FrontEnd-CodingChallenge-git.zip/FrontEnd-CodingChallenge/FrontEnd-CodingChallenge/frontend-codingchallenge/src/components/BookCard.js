// src/components/BookCard.js
import React from 'react';
import { Card, Button } from 'semantic-ui-react';

const BookCard = ({ book, onEdit, onDelete }) => {
  return (
    <Card color="blue" raised>
      <Card.Content>
        <Card.Header>{book.title}</Card.Header>
        <Card.Meta>{book.author}</Card.Meta>
        <Card.Description>
          <strong>ISBN:</strong> {book.isbn}
          <br />
          <strong>Publication Year:</strong> {book.publicationYear}
        </Card.Description>
      </Card.Content>
      <Card.Content extra style={{ display: 'flex', justifyContent: 'center', gap: '50px', }}>
        <Button color="blue" onClick={() => onEdit(book)}>
          Edit
        </Button>
        <Button color="red" onClick={() => onDelete(book.isbn)}>
          Delete
        </Button>
      </Card.Content>
    </Card>
  );
};

export default BookCard;
