// src/components/UpdateBookModal.js
import React, { useEffect, useState } from 'react';
import { Modal, Button, Form } from 'semantic-ui-react';

const UpdateBookModal = ({ open, onClose, book, onUpdate }) => {
  const [formData, setFormData] = useState(book || {});

  useEffect(() => {
    if (book) {
      setFormData(book);
    }
  }, [book]);

  const handleChange = (e, { name, value }) => {
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = () => {
    onUpdate(formData);
  };

  return (
    <Modal open={open} onClose={onClose} size="tiny">
      <Modal.Header>Update Book</Modal.Header>
      <Modal.Content>
        <Form onSubmit={handleSubmit}>
          <Form.Input label="ISBN" value={formData.isbn} disabled />
          <Form.Input label="Title" name="title" value={formData.title || ''} onChange={handleChange} />
          <Form.Input label="Author" name="author" value={formData.author || ''} onChange={handleChange} />
          <Form.Input
            label="Publication Year"
            name="publicationYear"
            type="number"
            value={formData.publicationYear || ''}
            onChange={handleChange}
          />
        </Form>
      </Modal.Content>
      <Modal.Actions>
        <Button onClick={onClose}>Cancel</Button>
        <Button positive onClick={handleSubmit}>
          Update
        </Button>
      </Modal.Actions>
    </Modal>
  );
};

export default UpdateBookModal;
