import React, { useEffect, useState } from 'react';
import { Card, Button, Header, Icon } from 'semantic-ui-react';
import axios from 'axios';
import BookCard from './BookCard';
import AddBookModal from './AddBookModal';
import UpdateBookModal from './UpdateBookModal';

const BookList = () => {
  const [books, setBooks] = useState([]);
  const [openAdd, setOpenAdd] = useState(false);
  const [openUpdate, setOpenUpdate] = useState(false);
  const [selectedBook, setSelectedBook] = useState(null);

  const fetchBooks = async () => {
    try {
      const token = localStorage.getItem('token'); 
      const response = await axios.get('http://localhost:9000/books', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setBooks(response.data);
      console.log('Books:', response.data);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleAdd = async (book) => {
    const token = localStorage.getItem('token');
    await axios.post('http://localhost:9000/books', book, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setOpenAdd(false);
    fetchBooks();
  };

  const handleUpdate = async (book) => {
    const token = localStorage.getItem('token');
    await axios.put(`http://localhost:9000/books/${book.isbn}`, book, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setOpenUpdate(false);
    fetchBooks();
  };

  const handleDelete = async (isbn) => {
    const token = localStorage.getItem('token');
    await axios.delete(`http://localhost:9000/books/${isbn}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchBooks();
  };

  return (
    <>
      <Header as="h2" icon textAlign="center">
        <Icon name="book" circular />
        <Header.Content>Book Management</Header.Content>
      </Header>

      <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
        <Button color="green" onClick={() => setOpenAdd(true)}>
          <Icon name="plus" /> Add Book
        </Button>
      </div>

      <Card.Group itemsPerRow={3} stackable>
        {books.map((book) => (
          <BookCard
            key={book.isbn}
            book={book}
            onEdit={(b) => {
              setSelectedBook(b);
              setOpenUpdate(true);
            }}
            onDelete={handleDelete}
          />
        ))}
      </Card.Group>

      <AddBookModal open={openAdd} onClose={() => setOpenAdd(false)} onAdd={handleAdd} />
      <UpdateBookModal
        open={openUpdate}
        onClose={() => setOpenUpdate(false)}
        book={selectedBook}
        onUpdate={handleUpdate}
      />
    </>
  );
};

export default BookList;
