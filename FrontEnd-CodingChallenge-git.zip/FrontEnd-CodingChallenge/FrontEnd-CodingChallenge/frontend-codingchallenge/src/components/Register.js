import React, { useState } from 'react';
import { Button, Form, Grid, Header, Message, Segment } from 'semantic-ui-react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const handleChange = (e, { name, value }) => {
    setFormData({ ...formData, [name]: value });
  };
  
  const handleSubmit = async () => {
    try {
      const response = await axios.post('http://localhost:9000/user/register', formData);
      setSuccess(response.data);
      setError('');
      setTimeout(() => navigate('/login'), 1500);
    } catch (err) {
      setError(err.response?.data || 'Registration failed');
      setSuccess('');
    }
  };
  
  return (
    <Grid 
      textAlign='center' 
      verticalAlign='middle' 
      style={{ 
        height: '100vh', 
        backgroundImage: 'url(https://source.unsplash.com/random/1600x900/?nature,abstract)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <Grid.Column style={{ 
        maxWidth: 400,
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        padding: '2em',
        borderRadius: '10px',
        boxShadow: '0 4px 8px rgba(0,0,0,0.2)'
      }}>
        <Header 
          as='h2' 
          color='teal' 
          textAlign='center'
          style={{ 
            fontSize: '2.5em',
            fontWeight: 'bold',
            marginBottom: '1.5em',
            color: '#1a8754'
          }}
        >
          Create your account
        </Header>
        <Form size='large' onSubmit={handleSubmit} style={{ fontSize: '1.1em' }}>
          <Segment stacked style={{ 
            padding: '2em',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px'
          }}>
            <Form.Input
              fluid
              icon='user'
              iconPosition='left'
              placeholder='Username'
              name='username'
              value={formData.username}
              onChange={handleChange}
              required
              style={{ 
                fontSize: '1.2em',
                padding: '1em',
                marginBottom: '1.5em'
              }}
            />
            <Form.Input
              fluid
              icon='lock'
              iconPosition='left'
              placeholder='Password'
              type='password'
              name='password'
              value={formData.password}
              onChange={handleChange}
              required
              style={{ 
                fontSize: '1.2em',
                padding: '1em',
                marginBottom: '1.5em'
              }}
            />
            <Button 
              color='teal' 
              fluid 
              size='large'
              style={{ 
                fontSize: '1.3em',
                fontWeight: 'bold',
                padding: '1em',
                backgroundColor: '#1a8754',
                borderColor: '#1a8754'
              }}
            >
              Register
            </Button>
          </Segment>
        </Form>
        {error && (
          <Message 
            negative 
            style={{ 
              fontSize: '1.1em',
              marginTop: '1.5em',
              backgroundColor: '#f8d7da',
              borderColor: '#f5c6cb',
              color: '#721c24'
            }}
          >
            {error}
          </Message>
        )}
        {success && (
          <Message 
            positive 
            style={{ 
              fontSize: '1.1em',
              marginTop: '1.5em',
              backgroundColor: '#d4edda',
              borderColor: '#c3e6cb',
              color: '#155724'
            }}
          >
            {success}
          </Message>
        )}
        <Message 
          style={{ 
            fontSize: '1.1em',
            marginTop: '1.5em',
            color: '#6c757d'
          }}
        >
          Already have an account? <a href='/login' style={{ color: '#1a8754', fontWeight: 'bold' }}>Login</a>
        </Message>
      </Grid.Column>
    </Grid>
  );
};

export default Register;