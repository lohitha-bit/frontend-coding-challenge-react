// src/components/Navbar.js
import React from 'react';
import { Menu, Container, Button } from 'semantic-ui-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Navbar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const activeItem = location.pathname;
  const isLoggedIn = !!localStorage.getItem('token');

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <Menu inverted>
      <Container>
        <Menu.Item header as={Link} to="/">
          Library Management
        </Menu.Item>
        {isLoggedIn && (
          <Menu.Item
            name="books"
            active={activeItem === '/'}
            as={Link}
            to="/"
          >
            Books
          </Menu.Item>
        )}
        {!isLoggedIn && (
          <>
            <Menu.Item
              name="login"
              active={activeItem === '/login'}
              as={Link}
              to="/login"
            >
              Login
            </Menu.Item>
            <Menu.Item
              name="register"
              active={activeItem === '/register'}
              as={Link}
              to="/register"
            >
              Register
            </Menu.Item>
          </>
        )}
        {isLoggedIn && (
          <Menu.Item position="right">
            <Button color="red" onClick={handleLogout}>
              Logout
            </Button>
          </Menu.Item>
        )}
      </Container>
    </Menu>
  );
};

export default Navbar;
